# Flutter Firebase Authentication

A sample project demonstrating firebase email and password authentication with Flutter.

## Getting Started

You will need to add your firebase project to run this repository.  See https://firebase.google.com/docs/flutter/setup for instructions
